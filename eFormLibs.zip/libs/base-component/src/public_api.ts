export * from './lib/base.component';
