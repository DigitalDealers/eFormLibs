export interface Config {
  aclConfig: any;
  envConfig: any;
  permissionClaims: any;
}
