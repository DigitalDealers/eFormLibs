export * from './lib/dealer-api.service';
export * from './lib/dealer-api.module';

export * from './lib/interfaces/data-set.interface';
