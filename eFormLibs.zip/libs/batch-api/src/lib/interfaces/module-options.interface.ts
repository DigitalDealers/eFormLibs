export interface ModuleOptions {
  appType?: number;
}
