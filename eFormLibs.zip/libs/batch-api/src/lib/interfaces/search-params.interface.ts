export interface SearchParams {
  query?: string;
  offset?: string;
  limit?: string;
}
