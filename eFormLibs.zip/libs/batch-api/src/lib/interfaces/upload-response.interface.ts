export interface UploadResponse {
  url: string;
  name: string;
}
