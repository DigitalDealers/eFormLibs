# Batch API library for eForms project
###Requires such dependencies (should be installed manually):
1. @digitaldealers/interceptors

###In your app module in imports section add configs for these modules:
1. DidiInterceptorsModule.forRoot({ batchApi: ..., ... })
2. HttpClientModule
