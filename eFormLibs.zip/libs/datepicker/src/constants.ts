import { InjectionToken } from '@angular/core';

export const eventToken = new InjectionToken('EVENT_DATA');
