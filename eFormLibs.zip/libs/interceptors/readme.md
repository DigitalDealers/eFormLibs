# Interceptors library for eForms project
###Requires such dependencies (should be installed manually):
1. angular-2-local-storage

###In your app module in imports section add configs for these modules:
1. LocalStorageModule.forRoot(...)
