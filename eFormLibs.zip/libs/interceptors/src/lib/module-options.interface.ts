export interface ModuleOptions {
  authBaseUrl?: string;
  chatBaseUrl?: string;
  batchApi?: string;
  baseUrl: string;
  dealerApi?: string;
  applicationId?: number;
}
