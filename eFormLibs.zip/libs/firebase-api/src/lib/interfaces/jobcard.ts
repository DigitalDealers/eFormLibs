export interface Jobcard {
  dealerId: number;
  startTime: Date;
  id: string;
  worker: string;
}
