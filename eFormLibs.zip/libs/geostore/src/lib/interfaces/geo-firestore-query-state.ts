export interface GeoFirestoreQueryState {
  active: boolean;
  childCallback: Function;
  valueCallback: Function;
}
