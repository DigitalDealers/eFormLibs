export interface QueryCriteria {
  center?: number[];
  radius?: number;
}
